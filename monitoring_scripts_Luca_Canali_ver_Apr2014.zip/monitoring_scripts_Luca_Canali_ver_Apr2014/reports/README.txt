This directory is intentionally empty. 
It is used to store the output of ash_report and awr_report among other scripts